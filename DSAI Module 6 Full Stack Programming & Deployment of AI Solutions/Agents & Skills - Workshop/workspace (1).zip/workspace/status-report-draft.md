# Customer Workshop — weekly status (DRAFT, not sent)

Week of 6 Jul 2026

Things are progressing. The team met on Tuesday and discussed several topics including the venue situation, catering options and the signup numbers. There was also discussion about the keynote speaker which is still being worked on. Raj has been talking to two venues and we should have more clarity soon hopefully by Friday. Daniel raised some points about the deposit timing which are important.

Signups are at 34 against our target of 80 which is something we are monitoring. Sarah will be sending a reminder.

More next week.

(TODO: Mei Lin wants these to look more professional before they go to management — fix structure??)
