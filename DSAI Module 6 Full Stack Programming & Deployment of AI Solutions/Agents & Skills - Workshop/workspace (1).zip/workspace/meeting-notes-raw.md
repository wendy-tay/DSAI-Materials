# notes tues mtg

ppl: ML, Raj, Daniel, Sarah (Jason away)

venue — raj called grand copthorne AND m hotel. copthorne quote 8.8k incl AV, m hotel 7.2k but AV extra ~1.5k?? raj to confirm av price by fri
ML says decision next week latest, invites cant go out without venue

catering — daniel: 68/pax buffet vs 85 seated. seated nicer but budget. IF we get 60+ signups buffet only option. parked.

signups — sarah: 34 confirmed as of tues, target 80. reminder email not sent yet?? sarah said will draft this week. ML wants to see draft before it goes

speaker — keynote still unconfirmed!!! ML chasing dr wong's office again. backup = internal speaker (jason?) but jason away til 28th, nobody asked him

daniel raised — deposit for venue due within 7 days of booking, needs finance approval first, finance takes 5 days. so venue decision basically needs to happen ASAP

next mtg tues 10am usual room

random: sarah asked abt name badges - nobody owned it. also parking coupons?
