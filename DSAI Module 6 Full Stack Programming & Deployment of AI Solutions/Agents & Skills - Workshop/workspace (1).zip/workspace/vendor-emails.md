# Email thread with Grand Copthorne (venue)

---

**From:** Raj
**To:** events@grandcopthorne.example.sg
**Date:** 7 Jul 2026
**Subject:** Workshop event

Hi,

Hope you are well. We spoke last week about our event. I wanted to follow up on a few things. We are still deciding between a few options and our team met recently to discuss. The date we are looking at is 12 September. We would have roughly 80 people but it could be more like 60 depending on signups, which are still coming in. I also wanted to ask about the AV setup since that was mentioned as included but we want to be sure what exactly is included, and also whether the quote you gave is still valid, and one more thing — is there parking validation for attendees?

Also could you let us know about the deposit terms?

Thanks so much,
Raj

---

**From:** events@grandcopthorne.example.sg
**To:** Raj
**Date:** 8 Jul 2026
**Subject:** RE: Workshop event

Dear Raj,

Thank you for your email. The quote of S$8,800 remains valid until 31 Jul 2026 and includes standard AV (projector, two handheld microphones, sound system). Recording equipment is available at additional cost. The deposit is 30% payable within 7 days of booking confirmation. Complimentary parking is provided for up to 20 vehicles; additional coupons can be arranged at S$8 per vehicle.

We look forward to hearing from you.

Best regards,
Events Team, Grand Copthorne
