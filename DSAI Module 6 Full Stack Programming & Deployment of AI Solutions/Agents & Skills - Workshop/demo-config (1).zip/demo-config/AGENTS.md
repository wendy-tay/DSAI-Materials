# AGENTS.md — Horizon customer workshop

## The project
The Horizon team is organising a customer workshop on 12 Sep 2026, target 80 attendees.

## People
- Mei Lin — project lead; sees every external draft before it is sent
- Raj — venue and logistics
- Daniel Tan — budget; all spending needs his line before finance approval
- Sarah — communications, signups, printing

## Conventions
- Dates are always written as 12 Sep 2026, never 9/12/26 or 12/09/26
- Amounts are always written as S$8,800 with the currency marker
- Team documents use first names; external documents use full names
- Tone for external email: warm, brief, one clear request per email

## When working with these documents
- The raw meeting notes use initials (ML = Mei Lin) — expand them in any output
- Anything marked "parked" is deliberately undecided; do not present it as a decision
