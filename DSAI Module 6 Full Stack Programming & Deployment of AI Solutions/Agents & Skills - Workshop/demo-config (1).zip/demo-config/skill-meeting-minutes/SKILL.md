---
name: meeting-minutes
description: >
  Turns raw meeting notes into structured minutes. Use when the user
  asks for minutes, a meeting summary, asks "what did we decide?",
  or says "tidy these notes" or "format these notes".
---

# Meeting minutes

When the user asks for minutes from raw notes:

1. Read the notes fully before writing. Expand initials into names using AGENTS.md.
2. Produce the minutes in this structure, in this order:
   - **Meeting details** — date, attendees, apologies
   - **Open questions** — every unresolved item, each with who can resolve it
   - **Decisions made** — only things actually decided; "parked" items are not decisions
   - **Action items** — a table: action, owner, due date (write "TBD" if none was stated)
   - **Next meeting**
3. Every action item must have exactly one named owner. If the notes leave an item unowned, list it under open questions instead, marked "needs an owner".

## NEVER

- Never invent attendees, dates, or owners that are not in the notes.
- Never promote a parked or discussed item into a decision.
- Never drop an item because it seems minor — small unowned items become next month's surprises.

## Exit criteria

- Every line of the raw notes is represented somewhere in the minutes.
- Every action item has one owner and a due date or "TBD".
- Open questions appear before action items.
