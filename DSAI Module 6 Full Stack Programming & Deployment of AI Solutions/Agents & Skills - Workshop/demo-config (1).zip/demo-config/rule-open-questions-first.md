# Rule: open questions before action items

In every response that summarises, reformats, or reports on the team's work, list the open questions and unresolved decisions BEFORE the action items. Unresolved matters are where the project's risk lives; they must never sit below the fold.

If a document contains no open questions, state that explicitly ("No open questions this week") rather than omitting the section.
